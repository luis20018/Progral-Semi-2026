IF DB_ID(N'db_academica') IS NULL CREATE DATABASE db_academica;
GO
USE db_academica;
GO
IF OBJECT_ID(N'dbo.usuarios_USTR078726', N'U') IS NULL
BEGIN
 CREATE TABLE dbo.usuarios_USTR078726 (
  idUsuario INT IDENTITY(1,1) PRIMARY KEY,
  usuario VARCHAR(35) NOT NULL UNIQUE,
  clave VARCHAR(35) NOT NULL,
  nombre VARCHAR(65) NOT NULL,
  direccion VARCHAR(85) NOT NULL,
  telefono VARCHAR(9) NOT NULL
 );
END;
GO
IF NOT EXISTS (SELECT 1 FROM dbo.usuarios_USTR078726 WHERE usuario='USTR078726')
 INSERT INTO dbo.usuarios_USTR078726(usuario,clave,nombre,direccion,telefono)
 VALUES ('USTR078726','luis1234','Luis','Usulután','77777777');
GO

IF NOT EXISTS (SELECT 1 FROM dbo.usuarios_USTR078726 WHERE usuario='usuario002')
 INSERT INTO dbo.usuarios_USTR078726(usuario,clave,nombre,direccion,telefono)
 VALUES ('usuario002','Prueba123','Usuario Dos','Usulutan','77770002');
IF NOT EXISTS (SELECT 1 FROM dbo.usuarios_USTR078726 WHERE usuario='usuario003')
 INSERT INTO dbo.usuarios_USTR078726(usuario,clave,nombre,direccion,telefono)
 VALUES ('usuario003','Prueba456','Usuario Tres','Usulutan','77770003');
GO
