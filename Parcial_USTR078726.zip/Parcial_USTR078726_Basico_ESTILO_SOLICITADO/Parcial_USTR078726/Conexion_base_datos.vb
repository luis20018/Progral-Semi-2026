Imports System
Imports System.Data
Imports System.Data.SqlClient

Public Class Conexion_base_datos
    Public Shared ReadOnly Cadena As String = "Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=db_academica;Integrated Security=True"
    Public ds As New DataSet()

    Public Sub crearDs()
        ds.Tables.Clear()
        Using cn As New SqlConnection(Cadena)
            Using da As New SqlDataAdapter("SELECT idUsuario, usuario, clave, nombre, direccion, telefono FROM dbo.usuarios_USTR078726 ORDER BY idUsuario", cn)
                da.Fill(ds, "usuarios_USTR078726")
            End Using
        End Using
    End Sub

    Public Function mantenimiento_usuarios_USTR078726(accion As String, id As Integer, usuario As String, clave As String, nombre As String, direccion As String, telefono As String) As Integer
        Dim sql As String
        Select Case accion.ToLowerInvariant()
            Case "nuevo"
                sql = "INSERT INTO dbo.usuarios_USTR078726(usuario,clave,nombre,direccion,telefono) VALUES(@usuario,@clave,@nombre,@direccion,@telefono)"
            Case "modificar"
                sql = "UPDATE dbo.usuarios_USTR078726 SET usuario=@usuario,clave=@clave,nombre=@nombre,direccion=@direccion,telefono=@telefono WHERE idUsuario=@id"
            Case "eliminar"
                sql = "DELETE FROM dbo.usuarios_USTR078726 WHERE idUsuario=@id"
            Case Else
                Throw New Global.System.ArgumentException("Acción inválida")
        End Select
        Using cn As New SqlConnection(Cadena)
            Using cmd As New SqlCommand(sql, cn)
                cmd.Parameters.Add("@id", SqlDbType.Int).Value = id
                cmd.Parameters.Add("@usuario", SqlDbType.VarChar, 35).Value = usuario
                cmd.Parameters.Add("@clave", SqlDbType.VarChar, 35).Value = clave
                cmd.Parameters.Add("@nombre", SqlDbType.VarChar, 65).Value = nombre
                cmd.Parameters.Add("@direccion", SqlDbType.VarChar, 85).Value = direccion
                cmd.Parameters.Add("@telefono", SqlDbType.VarChar, 9).Value = telefono
                cn.Open()
                Return cmd.ExecuteNonQuery()
            End Using
        End Using
    End Function

    Public Function ValidarLogin(usuario As String, clave As String) As Boolean
        Using cn As New SqlConnection(Cadena)
            Using cmd As New SqlCommand("SELECT COUNT(*) FROM dbo.usuarios_USTR078726 WHERE usuario=@usuario AND clave=@clave", cn)
                cmd.Parameters.Add("@usuario", SqlDbType.VarChar, 35).Value = usuario
                cmd.Parameters.Add("@clave", SqlDbType.VarChar, 35).Value = clave
                cn.Open()
                Return Global.System.Convert.ToInt32(cmd.ExecuteScalar()) > 0
            End Using
        End Using
    End Function
End Class
