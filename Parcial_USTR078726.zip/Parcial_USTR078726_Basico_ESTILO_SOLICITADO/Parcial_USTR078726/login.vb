Imports System
Imports System.Drawing
Imports System.Windows.Forms

Public Class login
    Inherits Form

    Private ReadOnly txtUsuario As New TextBox()
    Private ReadOnly txtClave As New TextBox()

    Public Sub New()
        Me.Text = "Iniciar sesión - USTR078726"
        Me.ClientSize = New Size(430, 220)
        Me.StartPosition = FormStartPosition.CenterScreen
        Me.FormBorderStyle = FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.BackColor = Color.White

        Dim titulo As New Label() With {
            .Text = "Iniciar sesión",
            .Font = New Font("Segoe UI", 13.0F, FontStyle.Bold),
            .AutoSize = True,
            .Location = New Point(145, 20)
        }

        Dim lblUsuario As New Label() With {
            .Text = "Usuario:",
            .Location = New Point(55, 70),
            .AutoSize = True
        }

        Dim lblClave As New Label() With {
            .Text = "Contraseña:",
            .Location = New Point(55, 112),
            .AutoSize = True
        }

        txtUsuario.SetBounds(150, 66, 220, 25)
        txtClave.SetBounds(150, 108, 220, 25)
        txtClave.UseSystemPasswordChar = True
        txtUsuario.Text = "USTR078726"

        Dim btnEntrar As New Button() With {
            .Text = "Iniciar sesión"
        }
        btnEntrar.SetBounds(150, 155, 220, 34)
        AddHandler btnEntrar.Click, AddressOf IniciarSesion

        Me.AcceptButton = btnEntrar

        Me.Controls.AddRange(New Control() {
            titulo, lblUsuario, lblClave, txtUsuario, txtClave, btnEntrar
        })
    End Sub

    Private Sub IniciarSesion(sender As Object, e As Global.System.EventArgs)
        Try
            If New Conexion_base_datos().ValidarLogin(txtUsuario.Text.Trim(), txtClave.Text) Then
                Me.Hide()
                Using principal As New frmPrincipal()
                    principal.ShowDialog()
                End Using
                Me.Close()
            Else
                MessageBox.Show("Usuario o contraseña incorrectos.")
            End If
        Catch ex As Global.System.Exception
            MessageBox.Show("No se pudo iniciar sesión: " & ex.Message)
        End Try
    End Sub
End Class
