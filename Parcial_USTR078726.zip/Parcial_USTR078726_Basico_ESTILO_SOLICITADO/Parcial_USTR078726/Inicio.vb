Imports System
Imports System.Windows.Forms

Public Module Inicio
    <Global.System.STAThread()>
    Public Sub Main()
        Application.EnableVisualStyles()
        Application.SetCompatibleTextRenderingDefault(False)
        Application.Run(New login())
    End Sub
End Module
