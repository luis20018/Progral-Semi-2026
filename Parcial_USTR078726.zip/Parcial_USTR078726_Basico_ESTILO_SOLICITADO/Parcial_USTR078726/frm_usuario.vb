Imports System
Imports System.Collections.Generic
Imports System.Data
Imports System.Drawing
Imports System.Windows.Forms

Public Class frm_usuario
    Inherits Form

    Private ReadOnly db As New Conexion_base_datos()
    Private ReadOnly campos As New Dictionary(Of String, TextBox)()
    Private ReadOnly tabla As New DataGridView()
    Private ReadOnly txtBuscar As New TextBox()
    Private ReadOnly lblPosicion As New Label()
    Private indice As Integer = 0
    Private modoNuevo As Boolean = False

    Public Sub New()
        Me.Text = "Administración de Usuarios - USTR078726"
        Me.ClientSize = New Size(995, 600)
        Me.StartPosition = FormStartPosition.CenterParent
        Me.BackColor = Color.WhiteSmoke

        Dim grpDatos As New GroupBox() With {
            .Text = "DATOS",
            .Location = New Point(18, 18),
            .Size = New Size(430, 395)
        }

        Dim nombres As String() = {"idUsuario", "usuario", "clave", "confirmar", "nombre", "direccion", "telefono"}
        Dim etiquetas As String() = {"ID:", "USUARIO:", "CLAVE:", "CONFIRMAR:", "NOMBRE:", "DIRECCIÓN:", "TELÉFONO:"}

        For i As Integer = 0 To nombres.Length - 1
            Dim lbl As New Label() With {
                .Text = etiquetas(i),
                .Location = New Point(22, 38 + i * 47),
                .AutoSize = True
            }

            Dim txt As New TextBox() With {
                .Location = New Point(125, 34 + i * 47),
                .Width = 265
            }

            If nombres(i) = "idUsuario" Then txt.ReadOnly = True
            If nombres(i) = "clave" OrElse nombres(i) = "confirmar" Then txt.UseSystemPasswordChar = True
            If nombres(i) = "usuario" Then txt.MaxLength = 35
            If nombres(i) = "clave" OrElse nombres(i) = "confirmar" Then txt.MaxLength = 35
            If nombres(i) = "nombre" Then txt.MaxLength = 65
            If nombres(i) = "direccion" Then txt.MaxLength = 85
            If nombres(i) = "telefono" Then txt.MaxLength = 9

            campos.Add(nombres(i), txt)
            grpDatos.Controls.Add(lbl)
            grpDatos.Controls.Add(txt)
        Next

        Me.Controls.Add(grpDatos)

        Dim lblBuscar As New Label() With {
            .Text = "Buscar:",
            .Location = New Point(475, 28),
            .AutoSize = True
        }
        txtBuscar.SetBounds(530, 24, 430, 25)
        AddHandler txtBuscar.TextChanged, AddressOf BuscarTexto

        Me.Controls.Add(lblBuscar)
        Me.Controls.Add(txtBuscar)

        tabla.SetBounds(475, 60, 485, 353)
        tabla.ReadOnly = True
        tabla.AllowUserToAddRows = False
        tabla.AllowUserToDeleteRows = False
        tabla.SelectionMode = DataGridViewSelectionMode.FullRowSelect
        tabla.MultiSelect = False
        tabla.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill
        tabla.RowHeadersVisible = False
        AddHandler tabla.SelectionChanged, AddressOf SeleccionFila
        Me.Controls.Add(tabla)

        Dim grpNavegacion As New GroupBox() With {
            .Text = "Navegación",
            .Location = New Point(18, 435),
            .Size = New Size(280, 110)
        }

        Dim btnPrimero As New Button() With {.Text = "|<", .Location = New Point(18, 42), .Size = New Size(45, 34)}
        Dim btnAnterior As New Button() With {.Text = "<", .Location = New Point(69, 42), .Size = New Size(45, 34)}
        lblPosicion.Text = "0 de 0"
        lblPosicion.Location = New Point(120, 50)
        lblPosicion.AutoSize = True
        Dim btnSiguiente As New Button() With {.Text = ">", .Location = New Point(181, 42), .Size = New Size(45, 34)}
        Dim btnUltimo As New Button() With {.Text = ">|", .Location = New Point(232, 42), .Size = New Size(45, 34)}

        AddHandler btnPrimero.Click, Sub(sender As Object, e As Global.System.EventArgs) Navegar(0)
        AddHandler btnAnterior.Click, Sub(sender As Object, e As Global.System.EventArgs) Navegar(indice - 1)
        AddHandler btnSiguiente.Click, Sub(sender As Object, e As Global.System.EventArgs) Navegar(indice + 1)
        AddHandler btnUltimo.Click, Sub(sender As Object, e As Global.System.EventArgs) Navegar(tabla.Rows.Count - 1)

        grpNavegacion.Controls.AddRange(New Control() {btnPrimero, btnAnterior, lblPosicion, btnSiguiente, btnUltimo})
        Me.Controls.Add(grpNavegacion)

        Dim grpEdicion As New GroupBox() With {
            .Text = "Edición",
            .Location = New Point(320, 435),
            .Size = New Size(455, 110)
        }

        Dim btnNuevo As New Button() With {.Text = "Nuevo", .Location = New Point(18, 30), .Size = New Size(125, 34)}
        Dim btnGuardar As New Button() With {.Text = "Guardar", .Location = New Point(165, 30), .Size = New Size(125, 34)}
        Dim btnModificar As New Button() With {.Text = "Modificar", .Location = New Point(312, 30), .Size = New Size(125, 34)}
        Dim btnCancelar As New Button() With {.Text = "Cancelar", .Location = New Point(18, 69), .Size = New Size(125, 34)}
        Dim btnEliminar As New Button() With {.Text = "Eliminar", .Location = New Point(165, 69), .Size = New Size(125, 34)}
        Dim btnActualizar As New Button() With {.Text = "Actualizar", .Location = New Point(312, 69), .Size = New Size(125, 34)}

        AddHandler btnNuevo.Click, AddressOf NuevoRegistro
        AddHandler btnGuardar.Click, AddressOf GuardarRegistro
        AddHandler btnModificar.Click, AddressOf ModificarRegistro
        AddHandler btnCancelar.Click, AddressOf CancelarEdicion
        AddHandler btnEliminar.Click, AddressOf EliminarRegistro
        AddHandler btnActualizar.Click, AddressOf ActualizarVista

        grpEdicion.Controls.AddRange(New Control() {
            btnNuevo, btnGuardar, btnModificar, btnCancelar, btnEliminar, btnActualizar
        })
        Me.Controls.Add(grpEdicion)

        AddHandler Me.Shown, Sub(sender As Object, e As Global.System.EventArgs) Cargar()
    End Sub

    Private Sub Cargar(Optional posicion As Integer = 0)
        db.crearDs()
        Dim dt As DataTable = db.ds.Tables("usuarios_USTR078726")
        tabla.DataSource = dt

        If tabla.Columns.Contains("clave") Then tabla.Columns("clave").Visible = False
        If tabla.Columns.Contains("idUsuario") Then tabla.Columns("idUsuario").FillWeight = 20
        If tabla.Columns.Contains("usuario") Then tabla.Columns("usuario").FillWeight = 35
        If tabla.Columns.Contains("nombre") Then tabla.Columns("nombre").FillWeight = 35
        If tabla.Columns.Contains("direccion") Then tabla.Columns("direccion").FillWeight = 35
        If tabla.Columns.Contains("telefono") Then tabla.Columns("telefono").FillWeight = 25

        If dt.Rows.Count > 0 Then
            Navegar(posicion)
        Else
            Limpiar()
            ActualizarPosicion()
        End If
    End Sub

    Private Sub Mostrar(i As Integer)
        If i < 0 OrElse i >= tabla.Rows.Count Then Return
        Dim r As DataGridViewRow = tabla.Rows(i)
        For Each nombre As String In New String() {"idUsuario", "usuario", "clave", "nombre", "direccion", "telefono"}
            campos(nombre).Text = Global.System.Convert.ToString(r.Cells(nombre).Value)
        Next
        campos("confirmar").Text = campos("clave").Text
        ActualizarPosicion()
    End Sub

    Private Sub SeleccionFila(sender As Object, e As Global.System.EventArgs)
        If tabla.SelectedRows.Count = 0 Then Return
        indice = tabla.SelectedRows(0).Index
        Mostrar(indice)
        modoNuevo = False
    End Sub

    Private Sub Limpiar()
        For Each t As TextBox In campos.Values
            t.Clear()
        Next
        campos("usuario").Focus()
    End Sub

    Private Sub ActualizarPosicion()
        If tabla.Rows.Count = 0 Then
            lblPosicion.Text = "0 de 0"
        Else
            lblPosicion.Text = (indice + 1).ToString() & " de " & tabla.Rows.Count.ToString()
        End If
    End Sub

    Private Function Validar() As Boolean
        If campos("usuario").Text.Trim().Length < 6 OrElse campos("usuario").Text.Trim().Length > 16 Then
            MessageBox.Show("El usuario debe tener entre 6 y 16 caracteres.")
            Return False
        End If

        Dim clave As String = campos("clave").Text
        If clave <> campos("confirmar").Text Then
            MessageBox.Show("Las contraseñas no coinciden.")
            Return False
        End If

        If clave.Length < 6 OrElse Not Global.System.Text.RegularExpressions.Regex.IsMatch(clave, "^(?=.*[A-Za-z])(?=.*[0-9]).+$") Then
            MessageBox.Show("La contraseña debe contener letras y números y tener al menos 6 caracteres.")
            Return False
        End If

        If campos("nombre").Text.Trim() = "" OrElse campos("direccion").Text.Trim() = "" OrElse campos("telefono").Text.Trim() = "" Then
            MessageBox.Show("Complete nombre, dirección y teléfono.")
            Return False
        End If

        Return True
    End Function

    Private Sub Navegar(i As Integer)
        If tabla.Rows.Count = 0 Then Return
        indice = Math.Max(0, Math.Min(i, tabla.Rows.Count - 1))
        tabla.ClearSelection()
        tabla.Rows(indice).Selected = True
        tabla.CurrentCell = tabla.Rows(indice).Cells("usuario")
        Mostrar(indice)
    End Sub

    Private Sub BuscarTexto(sender As Object, e As Global.System.EventArgs)
        Dim dt As DataTable = TryCast(tabla.DataSource, DataTable)
        If dt Is Nothing Then Return
        Dim filtro As String = txtBuscar.Text.Replace("'", "''").Replace("[", "[[]").Replace("%", "[%]").Replace("*", "[*]")
        dt.DefaultView.RowFilter = "usuario LIKE '%" & filtro & "%' OR nombre LIKE '%" & filtro & "%'"
        If dt.DefaultView.Count > 0 Then
            Navegar(0)
        Else
            ActualizarPosicion()
        End If
    End Sub

    Private Sub NuevoRegistro(sender As Object, e As Global.System.EventArgs)
        Limpiar()
        modoNuevo = True
        campos("idUsuario").Text = ""
    End Sub

    Private Sub GuardarRegistro(sender As Object, e As Global.System.EventArgs)
        If Not Validar() Then Return

        Dim id As Integer = 0
        Integer.TryParse(campos("idUsuario").Text, id)

        Dim operacion As String = If(modoNuevo OrElse id = 0, "nuevo", "modificar")
        db.mantenimiento_usuarios_USTR078726(
            operacion,
            id,
            campos("usuario").Text.Trim(),
            campos("clave").Text,
            campos("nombre").Text.Trim(),
            campos("direccion").Text.Trim(),
            campos("telefono").Text.Trim())

        modoNuevo = False
        Cargar()
        MessageBox.Show("Operación realizada correctamente.")
    End Sub

    Private Sub ModificarRegistro(sender As Object, e As Global.System.EventArgs)
        If campos("idUsuario").Text.Trim() = "" Then
            MessageBox.Show("Seleccione un usuario para modificar.")
            Return
        End If

        If Not Validar() Then Return

        Dim id As Integer = 0
        Integer.TryParse(campos("idUsuario").Text, id)
        db.mantenimiento_usuarios_USTR078726(
            "modificar",
            id,
            campos("usuario").Text.Trim(),
            campos("clave").Text,
            campos("nombre").Text.Trim(),
            campos("direccion").Text.Trim(),
            campos("telefono").Text.Trim())

        modoNuevo = False
        Cargar(indice)
        MessageBox.Show("Registro modificado correctamente.")
    End Sub

    Private Sub CancelarEdicion(sender As Object, e As Global.System.EventArgs)
        txtBuscar.Clear()
        modoNuevo = False
        If tabla.Rows.Count > 0 Then
            Navegar(indice)
        Else
            Limpiar()
        End If
    End Sub

    Private Sub EliminarRegistro(sender As Object, e As Global.System.EventArgs)
        Dim id As Integer = 0
        If Not Integer.TryParse(campos("idUsuario").Text, id) Then
            MessageBox.Show("Seleccione un usuario para eliminar.")
            Return
        End If

        If MessageBox.Show("¿Eliminar este usuario?", "Confirmación", MessageBoxButtons.YesNo) = DialogResult.Yes Then
            db.mantenimiento_usuarios_USTR078726("eliminar", id, "", "", "", "", "")
            Cargar(Math.Max(0, indice - 1))
        End If
    End Sub

    Private Sub ActualizarVista(sender As Object, e As Global.System.EventArgs)
        txtBuscar.Clear()
        Cargar(indice)
    End Sub
End Class
