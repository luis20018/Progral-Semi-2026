Imports System
Imports System.Drawing
Imports System.Windows.Forms

Public Class frmPrincipal
    Inherits Form
    Public Sub New()
        Me.Text = "frmPrincipal - USTR078726"
        Me.ClientSize = New Size(700, 450)
        Me.StartPosition = FormStartPosition.CenterScreen
        Me.IsMdiContainer = True
        Dim menu As New MenuStrip()
        Dim archivo As New ToolStripMenuItem("Archivo")
        Dim usuarios As New ToolStripMenuItem("Usuarios")
        Dim salir As New ToolStripMenuItem("Salir")
        AddHandler usuarios.Click, AddressOf AbrirUsuarios
        AddHandler salir.Click, Sub(sender As Object, e As Global.System.EventArgs) Me.Close()
        archivo.DropDownItems.Add(usuarios)
        archivo.DropDownItems.Add(salir)
        menu.Items.Add(archivo)
        Me.MainMenuStrip = menu
        Me.Controls.Add(menu)
    End Sub

    Private Sub AbrirUsuarios(sender As Object, e As Global.System.EventArgs)
        For Each f As Form In Me.MdiChildren
            If TypeOf f Is frm_usuario Then
                f.Activate()
                Return
            End If
        Next
        Dim ventana As New frm_usuario()
        ventana.MdiParent = Me
        ventana.Show()
    End Sub
End Class
